export const EntityNavbarItems = [];
